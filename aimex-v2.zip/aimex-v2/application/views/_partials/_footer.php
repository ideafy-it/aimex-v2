        <br>
        <footer class="footer">
            <div class="container">
                <span class="text-muted">Ideafy-it</span>
            </div>
        </footer>
        
        <script src="<?php echo base_url('assets/js/jquery-3.2.1.min.js');?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
        <script src="<?php echo base_url('assets/js/parsley.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/validator.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/scripts.js'); ?>"></script>
    </body>
</html>
