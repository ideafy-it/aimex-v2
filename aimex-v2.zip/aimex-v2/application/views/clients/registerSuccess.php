<div class="jumbotron jumbotron-fluid">
    <div class="container">
        <h1 class="display-4">The Client has been successfully been added</h1>
        <hr class="my-4">
        <p class="lead">Click here to search for the client's details and transaction.</p>
        <a href="<?php echo base_url(); ?>clients/home" class="btn btn-success">Seach Client</a>
    </div>
</div>